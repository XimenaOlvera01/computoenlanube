# Application Notes

Application of notes with encryption using Python.


## Contributing

#### Bug Reports & Feature Requests

Please use the [issue tracker](https://github.com/ronalruiiz/toolnotes/issues) to report any bugs or file feature requests.

